setwd("C:\\Users\\Jayawardhana\\Desktop\\IT24102310")

data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

fix(data)
attach(data)

weights <- Weight.kg.

#Q1
pop_mean <- mean(weights)
pop_sd   <- sd(weights)

print(paste("Population Mean =", pop_mean))
print(paste("Population SD =", pop_sd))

#Q2
set.seed(123)   # reproducibility
sample_means <- c()
sample_sds   <- c()

for (i in 1:25) {
  samp <- sample(weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(samp)
  sample_sds[i]   <- sd(samp)
}

print("Sample Means:")
print(sample_means)
print("Sample SDs:")
print(sample_sds)

#Q3
mean_of_sample_means <- mean(sample_means)
sd_of_sample_means   <- sd(sample_means)

print(paste("Mean of Sample Means =", mean_of_sample_means))
print(paste("SD of Sample Means =", sd_of_sample_means))